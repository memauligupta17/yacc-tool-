# Mini YACC Tool using C++

A small educational project that demonstrates lexical analysis and syntax analysis using **Flex**, **Bison (YACC)** and **C++**, with a **Streamlit** web interface.

## Features
- Accepts arithmetic expressions from the user.
- Flex identifies numbers and operators.
- Bison/YACC validates the expression using grammar rules.
- Semantic actions evaluate valid expressions.
- Supports `+`, `-`, `*`, `/`, `^`, parentheses, decimals and unary minus.
- Shows parser output in a Streamlit interface.

## Project structure

```text
yacc_cpp_streamlit/
├── app.py
├── parser.y
├── lexer.l
├── requirements.txt
├── packages.txt
├── .gitignore
└── README.md
```

## Run locally

You need Python 3.9+, a C++ compiler, Flex, and Bison.

### Ubuntu / Debian
```bash
sudo apt update
sudo apt install -y g++ flex bison
```

### Install Python dependencies and start
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository, for example `yacc-cpp-streamlit`.
2. Upload all project files to the **root** of the repository.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Select **Create app** and choose your repository.
5. Set the branch (usually `main`) and main file path to `app.py`.
6. Deploy. Streamlit Cloud reads `requirements.txt` for Python packages and `packages.txt` for system packages.

## Example

Input:
```text
(10 + 5) * 2 - 8 / 4
```

Expected result:
```text
Valid expression!
Result: 28
```

## Notes
- This is a teaching/demo parser for arithmetic expressions, not a general-purpose YACC replacement.
- The `.y` file contains the grammar and semantic actions.
- The `.l` file contains lexical rules.
- `app.py` invokes Bison, Flex and `g++` to build and run the parser.
